﻿using APIEndpoint.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace APIEndpoint.DataContext
{
    public class StoreContext : DbContext
    {
        public StoreContext(DbContextOptions<StoreContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
        }
        public DbSet<Result> Results { get; set; }
    }
}
