﻿namespace APIEndpoint.Models
{
    public class Result
    {
        public int Id { get; set; }
        public double collateralvalue { get; set; }
        public double totaloutstandingloanAmount { get; set; }
        public double scenarioCollateralValue { get; set; }
        public double recoveryRate { get; set; }
        public double lossGivenDefault { get; set; }
        public double expectedLoss { get; set; }
    }
}
