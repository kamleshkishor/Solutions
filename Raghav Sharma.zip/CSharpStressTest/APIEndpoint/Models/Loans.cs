﻿namespace APIEndpoint.Models
{
    public class Loans
    {
        //public int Id { get; set; }
        public int Loan_ID { get; set; }
        public int Port_ID { get; set; }
        public double  OriginalLoanAmount { get; set; }
        public double OutstandingAmount  { get; set; }
        public double CollateralValue { get; set; }

        public string CreditRating { get; set; }
    }
}
