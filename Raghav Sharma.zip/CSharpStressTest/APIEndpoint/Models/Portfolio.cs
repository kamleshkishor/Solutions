﻿namespace APIEndpoint.Models
{
    public class Portfolio
    {
        public int Port_ID { get; set; }
        public string Port_Name { get; set; }
        public string Port_Country { get; set; }
        public string Port_CCY { get; set; }
    }
}
