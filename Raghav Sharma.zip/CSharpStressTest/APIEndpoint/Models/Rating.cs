﻿using CsvHelper.Configuration.Attributes;

namespace APIEndpoint.Models
{
    public class Rating
    {
        //public int Id { get; set; }

        [Name ("Rating")]
        public string RatingName { get; set; }
        [Name("ProbablilityOfDefault")]
        public int ProbabliltyofDefault { get; set; }
    }
}
