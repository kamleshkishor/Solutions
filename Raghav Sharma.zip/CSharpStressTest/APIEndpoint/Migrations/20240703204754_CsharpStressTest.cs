﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace APIEndpoint.Migrations
{
    public partial class CsharpStressTest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Results",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    collateralvalue = table.Column<double>(type: "float", nullable: false),
                    totaloutstandingloanAmount = table.Column<double>(type: "float", nullable: false),
                    scenarioCollateralValue = table.Column<double>(type: "float", nullable: false),
                    recoveryRate = table.Column<double>(type: "float", nullable: false),
                    lossGivenDefault = table.Column<double>(type: "float", nullable: false),
                    expectedLoss = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Results", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Results");
        }
    }
}
