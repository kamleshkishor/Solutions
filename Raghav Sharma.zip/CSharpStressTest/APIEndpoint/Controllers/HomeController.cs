﻿using APIEndpoint.DataContext;
using APIEndpoint.Models;
using CsvHelper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIEndpoint.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class HomeController : ControllerBase
	{
		public StoreContext StoreContext { get; set; }
        public HomeController(StoreContext context)
        {
            StoreContext = context;
        }




     
        [HttpPost]
		//Route["FileRead"]
	   public Result FileRead(string inputvalue,double valuechanged)
		{
			
		   
			List<Portfolio> portfoliodata = new List<Portfolio>();
			List<Rating> ratingdata = new List<Rating>();
			List<Loans> loansdata = new List<Loans>();
			using(var reader = new StreamReader(@"C:\Users\portfolios.csv"))
			{
				using (var csvreader = new CsvReader(reader,CultureInfo.InvariantCulture))
				{
				  portfoliodata = csvreader.GetRecords<Portfolio>().ToList();
				   
				}
			}

			using (var reader = new StreamReader(@"C:\Users\ratings.csv"))
			{
				using (var csvreader = new CsvReader(reader, CultureInfo.InvariantCulture))
				{
					ratingdata = csvreader.GetRecords<Rating>().ToList();

				}
			}

			using (var reader = new StreamReader(@"C:\Users\loans.csv"))
			{
				using (var csvreader = new CsvReader(reader, CultureInfo.InvariantCulture))
				{
					loansdata = csvreader.GetRecords<Loans>().ToList();

				}
			}
		  var result =  portfoliodata.Find(data => data.Port_Country == inputvalue);
			var collateralvalue = loansdata.FindAll(data => data.Port_ID == result.Port_ID);
		var totaloutstandingloanAmount =   collateralvalue.Sum(data => data.OutstandingAmount);
            var LGD = loansdata.FindAll(data => data.Port_ID == result.Port_ID);
            List<double> scenarioCollateralValue = new List<double>();
            List<double> recoveryRate = new List<double>();
            List<double> lossGivenDefault = new List<double>();
			List<double> expectedLoss = new List<double>();
            for (int i = 0;i<collateralvalue.Count;i++)
			{
				scenarioCollateralValue.Add(collateralvalue[i].CollateralValue * (100 - valuechanged) / 100);
				recoveryRate.Add(scenarioCollateralValue[i] / collateralvalue[i].OriginalLoanAmount);
                lossGivenDefault.Add( 1 - recoveryRate[i] );
				var probabilityofDefault = ratingdata.Find(data => data.RatingName == LGD[i].CreditRating);
				expectedLoss.Add(probabilityofDefault.ProbabliltyofDefault * lossGivenDefault[i] * LGD[i].OutstandingAmount);
            }
			
			Result resultdata = new Result();
		resultdata.collateralvalue =	collateralvalue.Sum(data => data.CollateralValue);
			resultdata.totaloutstandingloanAmount = totaloutstandingloanAmount;
			resultdata.scenarioCollateralValue = scenarioCollateralValue.Sum();
			resultdata.recoveryRate = recoveryRate.Sum();
			resultdata.lossGivenDefault = lossGivenDefault.Sum();
			resultdata.expectedLoss = expectedLoss.Sum();

			if(resultdata !=  null)
			{
				StoreContext.Results.Add(resultdata);
				StoreContext.SaveChanges();
			}
			return resultdata; 

            //var totalCollateralAmount = scenariocollateralvalue.Sum(data => data.CollateralValue);
            //var scenarioCollateralValue = totalCollateralAmount * (100 - valuechanged) / 100;
            //var RecoveryRate = scenarioCollateralValue / totaloutstandingloanAmount;
            //var lossGivenDefault = 1 - RecoveryRate;
            //var eL = scenariocollateralvalue[0];
            //var expectedLoss = ratingdata.Find(data => data.RatingName == eL.CreditRating);
            //var ExpectedLoss = (expectedLoss.ProbabliltyofDefault * lossGivenDefault * totaloutstandingloanAmount);





        }
	}
}
