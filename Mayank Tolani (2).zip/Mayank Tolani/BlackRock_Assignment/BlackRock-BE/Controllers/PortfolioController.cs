﻿using BlackRock_BE.Contracts;
using BlackRock_BE.Models;
using Microsoft.AspNetCore.Mvc;

namespace BlackRock_BE;

[ApiController]
[Route("api/[controller]")]
public class PortfolioController : ControllerBase
{
    private readonly ICSVService _csvService;
    public PortfolioController(ICSVService csvService)
    {
        _csvService = csvService;
    }

    [HttpGet()]
    public IActionResult GetPortfolios()
    {
        List<Portfolio> portfolios = _csvService.ReadPortfolios("./Data/portfolios.csv");
        return Ok(portfolios);
    }
}
