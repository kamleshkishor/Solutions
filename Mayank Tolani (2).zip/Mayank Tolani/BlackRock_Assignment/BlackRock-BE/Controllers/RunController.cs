﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BlackRock_BE;

[ApiController]
[Route("api/[controller]")]
public class RunController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public RunController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("runs")]
    public async Task<IActionResult> GetRuns(int pageNumber = 1, int pageSize = 10)
    {
        int skip = (pageNumber - 1) * pageSize;

        var runs = await _context.Runs
        .Include(r => r.Results.OrderBy(res => res.PortfolioId))
        .Include(r => r.PercentageChanges)
        .OrderByDescending(r => r.Timestamp)
        .Skip(skip)
        .Take(pageSize)
        .ToListAsync();

        var totalRuns = await _context.Runs.CountAsync();
        var totalPages = (int)Math.Ceiling(totalRuns / (double)pageSize);

        var response = new
        {
            runs = runs,
            totalPages
        };

        return Ok(response);
    }

    [HttpGet("results/{runId}")]
    public async Task<IActionResult> GetResults(int runId)
    {
        var run = await _context.Runs.FirstOrDefaultAsync(r => r.Id == runId);
        if (run == null)
        {
            return NotFound();
        }
        return Ok(run);
    }
}
