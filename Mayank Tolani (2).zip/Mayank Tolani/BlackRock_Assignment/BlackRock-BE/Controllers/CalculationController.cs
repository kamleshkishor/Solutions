﻿using System.Diagnostics;
using BlackRock_BE.Contracts;
using BlackRock_BE.Models;
using BlackRock_BE.Repository;
using BlackRock_BE.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace BlackRock_BE.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CalculationController : ControllerBase
{
    private readonly ICSVService _csvService;
    private readonly ICalculationService _calculationService;
    private readonly ApplicationDbContext _context;
    private readonly ResultRepository _resultRepo;
    private readonly PercentageChangeRepository _percentageChangeRepo;
    public CalculationController(ICSVService csvService, ICalculationService calculationService, ApplicationDbContext context, ResultRepository resultRepo, PercentageChangeRepository percentageChangeRepository)
    {
        _csvService = csvService;
        _calculationService = calculationService;
        _context = context;
        _resultRepo = resultRepo;
        _percentageChangeRepo = percentageChangeRepository;
    }

    [HttpPost("calculate")]
    public async Task<IActionResult> Calculate([FromBody] Dictionary<string, double> percentageChanges)
    {
        List<Portfolio> portfolios = _csvService.ReadPortfolios("./Data/portfolios.csv");
        List<Loan> loans = _csvService.ReadLoans("./Data/loans.csv");
        List<CreditRating> ratings = _csvService.ReadRatings("./Data/ratings.csv");

        JObject returnObj = new JObject();
        var stopwatch = Stopwatch.StartNew();
        List<Result>? aggregatedResults = _calculationService.CalculateAggregatedResults(percentageChanges, portfolios, loans, ratings, returnObj);
        stopwatch.Stop();
        Run run = new Run
        {
            Timestamp = DateTime.Now,
            TimeTaken = (int)stopwatch.ElapsedMilliseconds
        };

        await _context.Runs.AddAsync(run);
        await _context.SaveChangesAsync();

        await _percentageChangeRepo.SavePercentageChanges(percentageChanges, run.Id);
        if(aggregatedResults is null){
            Log failedLog = new Log
            {
                Timestamp = run.Timestamp,
                Message = returnObj["Message"].ToString(),
                RunId = run.Id
            };
            await _context.Logs.AddAsync(failedLog);
            await _context.SaveChangesAsync();
            return BadRequest("Error calculating aggregated results");
        }

        await _resultRepo.SaveResults(aggregatedResults, run.Id);

        Log log = new Log
        {
            Timestamp = run.Timestamp,
            Message = "Calculation run completed.",
            RunId = run.Id
        };
        await _context.Logs.AddAsync(log);
        await _context.SaveChangesAsync();
        
        return Ok(aggregatedResults);
    }
}
