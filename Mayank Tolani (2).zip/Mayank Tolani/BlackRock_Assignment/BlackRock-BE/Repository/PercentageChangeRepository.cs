﻿using BlackRock_BE.Models;

namespace BlackRock_BE.Repository;

public class PercentageChangeRepository
{
    private readonly ApplicationDbContext _context;
    public PercentageChangeRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task SavePercentageChanges(Dictionary<string, double> percentageChanges, int runId)
    {
        foreach (var change in percentageChanges)
        {
            await _context.PercentageChanges.AddAsync(new PercentageChange
            {
                RunId = runId,
                Country = change.Key,
                Change = change.Value
            });
        }
    }
}
