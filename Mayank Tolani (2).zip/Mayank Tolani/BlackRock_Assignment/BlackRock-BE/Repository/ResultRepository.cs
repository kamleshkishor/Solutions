﻿using BlackRock_BE.Models;

namespace BlackRock_BE.Repository;

public class ResultRepository
{
    private readonly ApplicationDbContext _context;
    public ResultRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task SaveResults(List<Result> aggregatedResults, int runId)
    {
        foreach (Result result in aggregatedResults)
        {
            result.RunId = runId;
            await _context.Results.AddAsync(result);
        }
    }
}
