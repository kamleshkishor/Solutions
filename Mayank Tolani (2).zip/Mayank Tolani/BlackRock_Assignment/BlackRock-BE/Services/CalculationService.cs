﻿using BlackRock_BE.Contracts;
using BlackRock_BE.Models;
using Newtonsoft.Json.Linq;

namespace BlackRock_BE.Services;

public class CalculationService : ICalculationService
{
    private readonly ApplicationDbContext _context;
    private readonly CacheManager _cacheManager;
    public CalculationService(ApplicationDbContext context, CacheManager cacheManager)
    {
        _context = context;
        _cacheManager = cacheManager;
    }
    public List<Result>? CalculateAggregatedResults(Dictionary<string, double> percentageChanges, List<Portfolio> portfolios, List<Loan> loans, List<CreditRating> ratings, JObject returnObj){
        try{
            var pdLookup = ratings.ToDictionary(r => r.Rating, r => r.ProbablilityOfDefault/100);
            List<Result> aggregatedResults = loans
                .GroupBy(loan => loan.Port_ID)
                .Select(g =>
                {
                    int portId = g.Key;
                    List<Loan> loansInPortfolio = g.ToList();
                    Portfolio portfolio = portfolios.First(p => p.Port_ID == portId);

                    double totalOutstandingLoanAmount = _cacheManager.GetOrAdd(portId+"_TotalOutstandingLoanAmount", () =>
                    {
                        return loansInPortfolio.Sum(loan => loan.OutstandingAmount);
                    });

                    double totalCollateralValue = _cacheManager.GetOrAdd(portId+"_TotalCollateralValue", () =>
                    {
                        return loansInPortfolio.Sum(loan => loan.CollateralValue);
                    });

                    double scenarioCollateralValue = loansInPortfolio
                        .Sum(loan => 
                        {
                            double percentageChange = percentageChanges.ContainsKey(portfolio.Port_Country) ? percentageChanges[portfolio.Port_Country] : 0;
                            return loan.CollateralValue * (1 + (percentageChange / 100));
                        });

                    double expectedLoss = loansInPortfolio
                        .Sum(loan =>
                        {
                            double percentageChange = percentageChanges.ContainsKey(portfolio.Port_Country) ? percentageChanges[portfolio.Port_Country] : 0;
                            double scenarioCollateral = loan.CollateralValue * (1 + (percentageChange / 100));
                            double recoveryRate = scenarioCollateral / loan.OutstandingAmount;
                            double lossGivenDefault = 1 - recoveryRate;
                            double pd = pdLookup[loan.CreditRating];
                            return pd * lossGivenDefault * loan.OutstandingAmount;
                        });

                    Result res = new Result
                    {
                        PortfolioId = portId,
                        TotalOutstandingLoanAmount = Math.Round(totalOutstandingLoanAmount, 2),
                        TotalCollateralValue = Math.Round(totalCollateralValue, 2),
                        ScenarioCollateralValue = Math.Round(scenarioCollateralValue, 2),
                        ExpectedLoss = Math.Round(expectedLoss, 2)
                    };
                    return res;
                })
                .ToList();

            return aggregatedResults;
        }
        catch(Exception e){
            returnObj["StatusCode"] = 500;
            returnObj["Message"] = e.Message.ToString();
            return null;
        }
    }
}
