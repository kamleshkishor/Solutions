﻿using System.Globalization;
using BlackRock_BE.Contracts;
using BlackRock_BE.Models;
using CsvHelper;

namespace BlackRock_BE.Services;

public class CSVService : ICSVService
{
    public List<Portfolio> ReadPortfolios(string filePath)
    {
        using var reader = new StreamReader(filePath);
        using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
        return csv.GetRecords<Portfolio>().ToList();
    }

    public List<Loan> ReadLoans(string filePath)
    {
        using var reader = new StreamReader(filePath);
        using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
        return csv.GetRecords<Loan>().ToList();
    }

    public List<CreditRating> ReadRatings(string filePath)
    {
        using var reader = new StreamReader(filePath);
        using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
        return csv.GetRecords<CreditRating>().ToList();
    }
}
