﻿using Microsoft.Extensions.Caching.Memory;

namespace BlackRock_BE.Services;

public class CacheManager
{
    public readonly IConfiguration _configuration;
    private readonly IMemoryCache cache;
    private readonly MemoryCacheEntryOptions defaultCacheOptions;

    public CacheManager(IMemoryCache memoryCache, IConfiguration configuration)
    {
        cache = memoryCache;
        _configuration = configuration;
        defaultCacheOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(Convert.ToDouble(_configuration.GetSection("ApplicationConstants")["CacheDefaultAbsoluteExirationMinutes"])),
            SlidingExpiration = TimeSpan.FromMinutes(Convert.ToDouble(_configuration.GetSection("ApplicationConstants")["CacheSlidingExpirationMinutes"])),
        };
    }

    public T? GetOrAdd<T>(string key, Func<T> funcDelegate)
    {
        return cache.GetOrCreate(key, item => {
            item.SetOptions(defaultCacheOptions);
            return funcDelegate();
        });
    }
}
