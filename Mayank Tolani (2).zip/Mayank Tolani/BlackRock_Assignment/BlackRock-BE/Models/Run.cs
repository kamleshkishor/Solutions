﻿namespace BlackRock_BE.Models;

public class Run
{
    public int Id { get; set; }
    public DateTime Timestamp { get; set; }
    public int TimeTaken { get; set; }

    // Navigation properties
    public ICollection<Result> Results { get; set; } 
    public ICollection<PercentageChange> PercentageChanges { get; set; }
}
