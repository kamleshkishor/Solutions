﻿namespace BlackRock_BE.Models;

public class Loan
{
    public int Loan_ID { get; set; }
    public int Port_ID { get; set; }
    public double OriginalLoanAmount { get; set; }
    public double OutstandingAmount { get; set; }
    public double CollateralValue { get; set; }
    public string CreditRating { get; set; } = string.Empty;
}
