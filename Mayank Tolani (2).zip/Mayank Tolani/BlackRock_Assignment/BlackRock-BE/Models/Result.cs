﻿using System.ComponentModel.DataAnnotations;

namespace BlackRock_BE.Models;

public class Result
{
    [Required]
    public int Id { get; set; }
    [Required]
    public int RunId { get; set; }
    [Required]
    public int PortfolioId { get; set; }
    [Required]
    public double TotalOutstandingLoanAmount { get; set; }
    [Required]
    public double TotalCollateralValue { get; set; }
    [Required]
    public double ScenarioCollateralValue { get; set; }
    [Required]
    public double ExpectedLoss { get; set; }
    // public Run? Run { get; set; }
}
