﻿namespace BlackRock_BE.Models;

public class CreditRating
{
    public string Rating { get; set; } = string.Empty;
    public double ProbablilityOfDefault { get; set; }
}
