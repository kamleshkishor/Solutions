﻿namespace BlackRock_BE.Models;

public class Portfolio
{
    public int Port_ID { get; set; }
    public string Port_Name { get; set; } = string.Empty;
    public string Port_Country { get; set; } = string.Empty;
    public string Port_CCY { get; set; } = string.Empty;
}
