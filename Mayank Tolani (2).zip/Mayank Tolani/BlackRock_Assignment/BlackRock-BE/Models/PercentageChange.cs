﻿namespace BlackRock_BE.Models;

public class PercentageChange
{
    public int Id { get; set; }
    public int RunId { get; set; }
    public string Country { get; set; } = string.Empty;
    public double Change { get; set; }
    // public Run? Run { get; set; }

}
