﻿using BlackRock_BE.Models;
using Microsoft.EntityFrameworkCore;

namespace BlackRock_BE;

public class ApplicationDbContext : DbContext
{
    public DbSet<Run> Runs { get; set; }
    public DbSet<Result> Results { get; set; }
    public DbSet<PercentageChange> PercentageChanges { get; set; }
    public DbSet<Log> Logs { get; set; }
    
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Run>(entity =>
        {
            entity.HasKey(e => e.Id);
        });

        modelBuilder.Entity<Result>(entity =>
        {
            entity.HasKey(e => e.Id);
        });
        
        modelBuilder.Entity<PercentageChange>(entity =>
        {
            entity.HasKey(e => e.Id);
        });

        modelBuilder.Entity<Log>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasOne<Run>()
                .WithMany()
                .HasForeignKey(e => e.RunId);
        });
    }
}
