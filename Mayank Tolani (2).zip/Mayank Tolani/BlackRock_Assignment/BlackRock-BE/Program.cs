using BlackRock_BE;
using BlackRock_BE.Contracts;
using BlackRock_BE.Repository;
using BlackRock_BE.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
});


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<ICSVService, CSVService>();
builder.Services.AddScoped<ICalculationService, CalculationService>();
builder.Services.AddScoped<ResultRepository>();
builder.Services.AddScoped<PercentageChangeRepository>();

builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddMemoryCache();
builder.Services.AddSingleton<CacheManager>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


// app.UseMiddleware<ExceptionHandlingMiddleware>();

app.UseCors(x => x .AllowAnyMethod() .AllowAnyHeader().AllowAnyOrigin());

app.UseHttpsRedirection();

app.MapControllers();

app.Run();

record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
