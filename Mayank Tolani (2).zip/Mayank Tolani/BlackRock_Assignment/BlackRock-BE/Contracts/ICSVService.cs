﻿using BlackRock_BE.Models;

namespace BlackRock_BE.Contracts;

public interface ICSVService
{
    List<Portfolio> ReadPortfolios(string filePath);
    List<Loan> ReadLoans(string filePath);
    List<CreditRating> ReadRatings(string filePath);
}
