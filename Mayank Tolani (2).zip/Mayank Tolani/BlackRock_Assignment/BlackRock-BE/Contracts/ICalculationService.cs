﻿using BlackRock_BE.Models;
using Newtonsoft.Json.Linq;

namespace BlackRock_BE.Contracts;

public interface ICalculationService
{
    public List<Result>? CalculateAggregatedResults(Dictionary<string, double> percentageChanges, List<Portfolio> portfolios, List<Loan> loans, List<CreditRating> ratings, JObject returnObj);
}
