
CREATE DATABASE BlackRock_BE
USE BlackRock_BE

CREATE TABLE Runs (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Timestamp DATETIME NOT NULL,
    TimeTaken INT NOT NULL
);

CREATE TABLE Results (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    RunId INT NOT NULL,
    PortfolioId INT NOT NULL,
    TotalOutstandingLoanAmount FLOAT NOT NULL,
    TotalCollateralValue FLOAT NOT NULL,
    ScenarioCollateralValue FLOAT NOT NULL,
    ExpectedLoss FLOAT NOT NULL,
    FOREIGN KEY (RunId) REFERENCES Runs(Id)
);

CREATE TABLE PercentageChanges (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    RunId INT NOT NULL,
    Country NVARCHAR(MAX) DEFAULT '',
    Change FLOAT NOT NULL,
    FOREIGN KEY (RunId) REFERENCES Runs(Id)
);

CREATE TABLE Logs (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Timestamp DATETIME NOT NULL,
    Message NVARCHAR(MAX) NOT NULL,
    RunId INT NOT NULL,
    FOREIGN KEY (RunId) REFERENCES Runs(Id)
);

