import React, { useState, useEffect } from 'react';
import {
    Container,
    CssBaseline,
    AppBar,
    Toolbar,
    Typography,
    Snackbar,
    Alert,
    Box,
} from '@mui/material';
import PercentageChangeForm from './Components/Form';
import RunList from './Components/RunsList';
import { fetchRuns, fetchPortfolios, handleSubmit } from './Helpers/helper';

const App = () => {
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [snackbarSeverity, setSnackbarSeverity] = useState('success');
    const [runs, setRuns] = useState([]);
    const [portfolios, setPortfolios] = useState([]);
    const [pageNumber, setPageNumber] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    useEffect(() => {
        fetchRuns(setRuns, setTotalPages, pageNumber, setPageNumber, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen);
        fetchPortfolios(setPortfolios, setSnackbarMessage);
    }, []);

    const handleSnackbarClose = () => {
        setSnackbarOpen(false);
    };

    const handlePageChange = (event, newPage) => {
        setPageNumber(newPage);
        fetchRuns(setRuns, setTotalPages, newPage, setPageNumber, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen);
    };

    return (
        <>
            <CssBaseline />
            <AppBar position="static" style={{background:"black"}}>
                <Toolbar>
                    <Typography variant="h6">
                        BlackRock Assignment
                    </Typography>
                </Toolbar>
            </AppBar>
            <Container style={{ marginTop: '20px' }}>
                <PercentageChangeForm onSubmit={(percentageChanges) => handleSubmit(percentageChanges, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen, () => fetchRuns(setRuns, setTotalPages, pageNumber, setPageNumber, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen))}/>
                {runs && runs.length > 0 ? (
                    <RunList
                        runs={runs}
                        portfolios={portfolios}
                        pageNumber={pageNumber}
                        onPageChange={handlePageChange}
                        totalPages={totalPages}
                    />
                ) : (
                    <Box mt={3} display="flex" justifyContent="center">
                    <Typography variant="body1" alignItems={"center"} justifyContent={"center"} display={"flex"}>Run History Not Available!</Typography>
                    </Box>
                )}
            </Container>
            <Snackbar open={snackbarOpen} autoHideDuration={2000} onClose={handleSnackbarClose}>
                <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </>
    );
};

export default App;
