const host = process.env.REACT_APP_API_BASE_URL;

const fetchRuns = async (setRuns, setTotalPages, pageNumber, setPageNumber, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen) => {
    try {
        const response = await fetch(`${host}/Run/runs?pageNumber=${pageNumber}`);

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        setRuns(data.runs);
        setTotalPages(data.totalPages);
    } catch (error) {
        setSnackbarMessage('Error fetching runs. Please try again.');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
    }
};

const fetchPortfolios = async (setPortfolios, setSnackbarMessage) => {
    try {
        const response = await fetch(`${host}/Portfolio`);

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        setPortfolios(data);
    } catch (error) {
        console.error('Error fetching portfolios:', error);
        setSnackbarMessage('Error fetching portfolios. Please try again.');
    }
};

const handleSubmit = async (percentageChanges, setSnackbarMessage, setSnackbarSeverity, setSnackbarOpen, fetchRuns) => {
    try {
        const response = await fetch(`${host}/Calculation/calculate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(percentageChanges),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log('Calculation result:', data);

        setSnackbarMessage('Calculation completed successfully!');
        setSnackbarSeverity('success');
        setSnackbarOpen(true);

        // Update runs list after successful calculation
        fetchRuns();
    } catch (error) {
        console.error('Error during calculation:', error);
        setSnackbarMessage('Failed to complete calculation. Please try again.');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
    }
};

function formatDate(timestamp) {
    const date = new Date(timestamp);
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return date.toLocaleDateString('en-US', options);
}

export { fetchRuns, fetchPortfolios, handleSubmit, formatDate };
