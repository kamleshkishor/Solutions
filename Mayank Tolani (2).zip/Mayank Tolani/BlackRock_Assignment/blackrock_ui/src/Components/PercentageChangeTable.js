import React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, Box } from '@mui/material';

const PercentageChangeTable = ({ percentageChanges }) => {
    return (
        <Box>
            <Typography variant="h6" gutterBottom>
                Percentage Changes
            </Typography>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell style={{ fontWeight: 'bold', backgroundColor: 'black', color: 'white' }}>
                                Country
                            </TableCell>
                            {percentageChanges.map((pc, index) => (
                                <TableCell key={`head-${index}`} style={{ fontWeight: 'bold', backgroundColor: 'black', color: 'white' }}>
                                    {pc.country}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        <TableRow>
                            <TableCell>
                                Percentage Change
                            </TableCell>
                            {percentageChanges.map((pc, index) => (
                                <TableCell key={`body-${index}`}>
                                    {pc.change}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    );
};

export default PercentageChangeTable;
