import React, { useState } from 'react';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Typography,
    Pagination,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import PercentageChangeTable from './PercentageChangeTable';
import ResultsTable from './ResultsTable';
import { formatDate } from '../Helpers/helper';

const RunList = ({ runs, portfolios, pageNumber, onPageChange, totalPages }) => {
    const [expandedRunId, setExpandedRunId] = useState(null);

    const handleChangePage = (event, newPage) => {
        onPageChange(event, newPage);
    };

    const handleAccordionChange = (runId) => {
        if (expandedRunId === runId) {
            setExpandedRunId(null);
        } else {
            setExpandedRunId(runId);
        }
    };
    const tableCellStyle = {fontWeight: 'bold', backgroundColor: 'black', color: 'white'}
    return (
        <Box mt={3}>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell style={tableCellStyle}>Run ID</TableCell>
                            <TableCell style={tableCellStyle}>Timestamp</TableCell>
                            <TableCell style={tableCellStyle}>Time Taken (ms)</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {runs.map((run, index) => (
                            <React.Fragment key={run.id}>
                                <TableRow>
                                    <TableCell>{run.id}</TableCell>
                                    <TableCell>{formatDate(run.timestamp)}</TableCell>
                                    <TableCell>{run.timeTaken}</TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell colSpan={3} style={{ paddingBottom: 0, paddingTop: 0 }}>
                                        <Accordion expanded={expandedRunId === run.id} onChange={() => handleAccordionChange(run.id)}>
                                            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                                                <Typography variant="body2">Details</Typography>
                                            </AccordionSummary>
                                            <AccordionDetails>
                                                <Box width="100%">
                                                    <PercentageChangeTable percentageChanges={run.percentageChanges} />
                                                    <ResultsTable results={run.results} portfolios={portfolios} />
                                                </Box>
                                            </AccordionDetails>
                                        </Accordion>
                                    </TableCell>
                                </TableRow>
                                {index !== runs.length - 1 && (
                                    <TableRow>
                                        <TableCell colSpan={3}>
                                            <Box height={20} />
                                        </TableCell>
                                    </TableRow>
                                )}
                            </React.Fragment>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <Box my={2} display="flex" justifyContent="center">
                <Pagination
                    count={totalPages}
                    page={pageNumber}
                    onChange={handleChangePage}
                    color="primary"
                    size="large"
                    showFirstButton
                    showLastButton
                />
            </Box>
        </Box>
    );
};

export default RunList;
