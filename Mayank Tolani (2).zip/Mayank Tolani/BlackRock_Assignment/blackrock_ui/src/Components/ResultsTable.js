import React from 'react';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Typography,
    Box
} from '@mui/material';

const ResultsTable = ({ results, portfolios }) => {
    return (
        <Box marginTop={4}>
            <Typography variant="h6" gutterBottom>Results</Typography>
            <TableContainer>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Portfolio Name</TableCell>
                            <TableCell>Currency</TableCell>
                            <TableCell>Country</TableCell>
                            <TableCell>Total Outstanding Loan Amount</TableCell>
                            <TableCell>Total Collateral Value</TableCell>
                            <TableCell>Scenario Collateral Value</TableCell>
                            <TableCell>Expected Loss</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {results.map((res, index) => (
                            <TableRow key={res.id} style={{ backgroundColor: index % 2 === 0 ? '#f9f9f9' : '#fff' }}>
                                <TableCell>{portfolios.find(p => p.port_ID === res.portfolioId)?.port_Name}</TableCell>
                                <TableCell>{portfolios.find(p => p.port_ID === res.portfolioId)?.port_CCY}</TableCell>
                                <TableCell>{portfolios.find(p => p.port_ID === res.portfolioId)?.port_Country}</TableCell>
                                <TableCell>{res.totalOutstandingLoanAmount}</TableCell>
                                <TableCell>{res.totalCollateralValue}</TableCell>
                                <TableCell>{res.scenarioCollateralValue}</TableCell>
                                <TableCell>{res.expectedLoss}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    );
};

export default ResultsTable;
