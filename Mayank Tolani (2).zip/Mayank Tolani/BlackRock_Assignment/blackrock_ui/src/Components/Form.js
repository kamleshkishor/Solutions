import React, { useState } from 'react';
import { TextField, Button, Container, Grid, Typography } from '@mui/material';

const Form = ({ onSubmit }) => {
    const initialPercentageChanges = {
        GB: 0,
        US: 0,
        FR: 0,
        DE: 0,
        SG: 0,
        GR: 0,
    };

    const [percentageChanges, setPercentageChanges] = useState(initialPercentageChanges);
    const [errors, setErrors] = useState({});
    const [disabled, setDisabled] = useState(false);

    const handleChange = (country) => (event) => {
        const value = event.target.value;

        const isValid = /^-?\d*\.?\d{0,2}$/.test(value);

        if (isValid) {
            if(value === '-'){
                setPercentageChanges({ ...percentageChanges, [country]: value });
                setErrors({ ...errors, [country]: true });
                setDisabled(true)
            }
            else{
                setPercentageChanges({ ...percentageChanges, [country]: value });
                setErrors({ ...errors, [country]: false });
                setDisabled(false)
            }
        }
    };

    const handleSubmit = (event) => {
        event.preventDefault();

        const parsedValues = Object.keys(percentageChanges).reduce((acc, country) => {
            acc[country] = parseFloat(percentageChanges[country]);
            return acc;
        }, {});

        onSubmit(parsedValues);
    };

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                Percentage Change In House Prices
            </Typography>
            <form onSubmit={handleSubmit}>
                <Grid container spacing={3} marginY={2}>
                    {Object.keys(percentageChanges).map((country) => (
                        <Grid item xs={12} sm={6} md={4} key={country}>
                            <TextField
                                fullWidth
                                variant="outlined"
                                label={country}
                                type="text"
                                value={percentageChanges[country]}
                                onChange={handleChange(country)}
                                error={errors[country]}
                                helperText={errors[country] ? 'Invalid number' : ''}
                                required
                            />
                        </Grid>
                    ))}
                </Grid>
                <Button type="submit" variant="contained" color="primary" style={{ marginTop: '20px', background:"black" }} disabled={disabled}>
                    Submit
                </Button>
            </form>
        </Container>
    );
};

export default Form;
