/*This contain two folder

LoanBackend=>  
-------------
Need to run on local 
API's
	i)Calculate
	ii)CalculateSaveInDb
	iii)runs
	iv)results/{runId}
Technology used:->.NET core WEB API,sqlite,Entity FrameWork

Databases queries
----------------
sqlite3 loans.db
 .tables
select * from AggregatedResults;
select * from CalculationRuns;

LoanFrontend=>
-------------
Need to run on local 
Submit button-submit the data in DB
Runs button-fetch the data with run id
View Results-Get the data on the basis of runId
Technology used:->React.js

*/