﻿namespace LoanApplication.Model
{
    public class Ratings
    {
        public string Rating { get; set; }
        public double ProbablilityOfDefault { get; set; }
    }
}
